function w=fapj(x);
w=x/30+0.35*exp(-(x/6.4140)^2)+(0.15/9)*exp(x/7);
