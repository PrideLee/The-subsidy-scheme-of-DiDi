clear all;
fid=fopen('C:\Users\lenovo\Desktop\�½��ı��ĵ�.txt','r');
         var=fread(fid,'*char');
         c=var';
         var=native2unicode(var)';
         a=length(var);
         var
     a