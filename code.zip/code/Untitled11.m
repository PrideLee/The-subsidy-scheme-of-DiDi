clear all;
[x,fval]=fmincon('fapj',2,[],[],[],[],2,15)