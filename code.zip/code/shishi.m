clear all;
clc;
v1=[];
i=1;
while i<3
         a='E:4\';
         e='.txt';
         b=[a num2str(i)  e];
         fid=fopen(b,'r');
         var=fread(fid,'*char');
         c=var';
         var=native2unicode(var)';
         v1=[v1,var];
         i=i+1;
end
v1